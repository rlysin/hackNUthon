# mypro1
This is an HR Management system project . For an college final year project . Created using HTML5, CSS3, JAVASCRIPT, AJAX , PHP AND MYSQL.


Use below link 
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.6.1/chart.js" integrity="sha512-9fQaGKKJO2zXOYXpPTEEyzIdx7r3ou0nZgvxS9VICh70AGvdangg7lUVonofpBYrNWd6h2e/FQHoWSCRZkwOUQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

where ever js/Char.js file is used
For an Chart.js file missing in js folder
