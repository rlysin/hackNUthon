import DepartmentsModify from "./DatabaseModify/DepartmentsModify";

const ModifyDatabase = () => {
  return <DepartmentsModify />;
};
export default ModifyDatabase;
