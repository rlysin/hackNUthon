import React from "react";

import Page from "../components/Page";

const Holidays = () => {
  return (
    <Page title="HR Core - Holidays">
      <div>Coming soon...</div>
    </Page>
  );
};

export default Holidays;
